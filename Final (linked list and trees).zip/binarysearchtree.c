#include <stdio.h>
#include <stdlib.h>
struct Node
{
 struct Node *lchild;
 int data;
 struct Node *rchild;
}*root=NULL;
void Insert(int key)
{
 struct Node *t=root;
 struct Node *r=NULL,*p;
 
 if(root==NULL)
 {
 p=(struct Node *)malloc(sizeof(struct Node));
 p->data=key;
 p->lchild=p->rchild=NULL;
 root=p;
 return;
 }
 while(t!=NULL)
 {
 r=t;
 if(key<t->data)
 t=t->lchild;
 else if(key>t->data)
 t=t->rchild;
 else
 return;
 }
 p=(struct Node *)malloc(sizeof(struct Node));
 p->data=key;
 p->lchild=p->rchild=NULL;
 
 if(key<r->data) r->lchild=p;
 else r->rchild=p;
}
void Inorder(struct Node *p)
{
 if(p)
 {
 Inorder(p->lchild);
 printf("%d ",p->data);
 Inorder(p->rchild);
 }
}
struct Node * Search(int key)
{
 struct Node *t=root;
 
 while(t!=NULL)
 {
 if(key==t->data)
 return t;
 else if(key<t->data)
 t=t->lchild;
 else
 t=t->rchild;
 }
 return NULL;
}
struct Node *RInsert(struct Node *p,int key)
{
 struct Node *t=NULL;
 
 if(p==NULL)
 {
 t=(struct Node *)malloc(sizeof(struct Node));
 t->data=key;
 t->lchild=t->rchild=NULL;
 return t;
 }
 if(key < p->data)
 p->lchild=RInsert(p->lchild,key);
 else if(key > p->data)
 p->rchild=RInsert(p->rchild,key);
 
 return p;
 
 
}
int Height(struct Node *p)
{
 int x,y;
 if(p==NULL)return 0;
 x=Height(p->lchild);
 y=Height(p->rchild);
 return x>y?x+1:y+1;
}
struct Node *InPre(struct Node *p)
{
 while(p && p->rchild!=NULL)
 p=p->rchild;
 
 return p;
}
struct Node *InSucc(struct Node *p)
{
 while(p && p->lchild!=NULL)
 p=p->lchild;
 
 return p;
}
struct Node *Delete(struct Node *p,int key)
{
 struct Node *q;
 
 if(p==NULL)
 return NULL;
 if(p->lchild==NULL && p->rchild==NULL)
 {
 if(p==root)
 root=NULL;
 free(p);
 return NULL;
 
 }
 
 if(key < p->data)
 p->lchild=Delete(p->lchild,key);
 else if(key > p->data)
 p->rchild=Delete(p->rchild,key);
 else
 {
 if(Height(p->lchild)>Height(p->rchild))
 {
 q=InPre(p->lchild);
 p->data=q->data;
 p->lchild=Delete(p->lchild,q->data);
 }
 else
 {
 q=InSucc(p->rchild);
 p->data=q->data;
 p->rchild=Delete(p->rchild,q->data);
 }
 
 
 }
 return p;
}
int main()
{
 struct Node *temp;
 int op,x;
 while(1)
 {
    printf("\nChoose one of the following\n");
  printf("1.Inser element\n2.Delete element\n3.Search inorder\n4.Display\n5.Quit\n\n");
  printf("Enter choice: ");
  scanf("%d",&op);
  switch(op)
  {
  case 1:
  printf("Enter an element to insert: ");
  scanf("%d",&x);
  root=RInsert(root,x);
  break;
  case 2:
  printf("Enter an element to delete: ");
  scanf("%d",&x);
  root=Delete(root,x);
  break;
 
  case 3:
  printf("Enter element to search:");
  scanf("%d",&x);
  temp=Search(x);
  if(temp!=NULL)
printf("element %d is found\n",temp->data);
  else
printf("element is not found\n");
break;
 
  case 4:
  Inorder(root);
  break;
  case 5:
  exit(1);
  default:
  printf("Wrong choice!!! Please enter again:");
  break;
 }
 }
 return 0;
 }


