#include <stdio.h>
#include <stdlib.h>

struct Node {
  int data;
  struct Node* next;
};

struct Node *tail=NULL;

void insertAtBeginning(struct Node** head_ref, int new_data) {
  struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));

  new_node->data = new_data;

  new_node->next = (*head_ref);
  (*head_ref) = new_node;
}

void insertAtEnd(struct Node** head_ref, int new_data) {
  struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));
  struct Node* last = *head_ref;

  new_node->data = new_data;
  new_node->next = NULL;

  if (*head_ref == NULL) {
  *head_ref = new_node;
  return;
  }

  while (last->next != NULL)
  last = last->next;

  last->next = new_node;
  return;
}

int Count1(struct Node *p)
{
    int l = 0;
    while (p)
    {
        l++;
        p = p->next;
    }
    return l;
}

void deleteNode(struct Node** head_ref, int key)
{
    struct Node *temp = *head_ref, *prev;
 
    if (temp != NULL && temp->data == key) {
        *head_ref = temp->next;
        free(temp);
        return;
    }
    while (temp != NULL && temp->data != key) {
        prev = temp;
        temp = temp->next;
    }
    if (temp == NULL)
        return;
    prev->next = temp->next;
    free(temp);
}

void sortLinkedList(struct Node** head_ref) {
  struct Node *current = *head_ref, *index = NULL;
  int temp;

  if (head_ref == NULL) {
  return;
  } else {
  while (current != NULL) {
    index = current->next;

    while (index != NULL) {
    if (current->data > index->data) {
      temp = current->data;
      current->data = index->data;
      index->data = temp;
    }
    index = index->next;
    }
    current = current->next;
  }
  }
}

void sortedInsert(struct Node** head_ref,
                  struct Node* new_node)
{
    struct Node* current;
    if (*head_ref == NULL
        || (*head_ref)->data
               >= new_node->data) {
        new_node->next = *head_ref;
        *head_ref = new_node;
    }
    else {
        current = *head_ref;
        while (current->next != NULL
               && current->next->data < new_node->data) {
            current = current->next;
        }
        new_node->next = current->next;
        current->next = new_node;
    }
}
 
struct Node* newNode(int new_data)
{
    struct Node* new_node
= (struct Node*)malloc(
sizeof(struct Node));
 
    new_node->data = new_data;
    new_node->next = NULL;
 
    return new_node;
}

void printList(struct Node* node) {
  while (node != NULL) {
  printf(" %d ", node->data);
  node = node->next;
  }
}

struct Node* copyList(struct Node* head)
{
    if (head == NULL) {
        return NULL;
    }
    else {
        struct Node* newNode
            = (struct Node*)malloc(
                sizeof(struct Node));
 
        newNode->data = head->data;
 
        newNode->next = copyList(head->next);
 
        return newNode;
    }
}

void addInMid(struct Node *head, int data, int size){
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));  
    newNode->data = data;  
    newNode->next = NULL;  
     
    if(head == NULL) {  
        head = newNode;  
        tail = newNode;  
    }  
    else {  
        struct Node *temp, *current;  
        int count = (size % 2 == 0) ? (size/2) : ((size+1)/2);  
        temp = head;  
        current = NULL;  
   
        for(int i = 0; i < count; i++) {  
            current = temp;  
            temp = temp->next;  
        }  
        current->next = newNode;
        newNode->next = temp;  
    }  
    size++;  
}  

int main() {
  struct Node* head = NULL;
  struct Node* dup =NULL;
  struct Node* new_node;
  int op=0;
  int x,s;
  while (1)
    {
        printf("Enter operation you want to perform:\n");
        printf("1. Insert at first\n2. Insert at last\n3. Insert in ordered link list\n4. Delete\n5. Copy Linked List\n6. Display\n7. Size of the linklist.\n8. Insert Node at intermediate\n9. Quit.\n");
        scanf("%d", &op);
        switch (op)
        {
        case 1:
            printf("Enter an element to insert at first: ");
            scanf("%d", &x);
            insertAtBeginning(&head, x);
            break;

        case 2:
            printf("Enter an element to insert at last: ");
            scanf("%d", &x);
            insertAtEnd(&head, x);
            break;
       
        case 3:
            sortLinkedList(&head);
            printf("Enter an element into sorted list: ");
            scanf("%d", &x);
            new_node = newNode(x);
            sortedInsert(&head,new_node);
            break;

        case 4:
            printf("Enter an index to delete: ");
            scanf("%d", &x);
            deleteNode(&head, x);
            break;
       
        case 5:
            dup= copyList(head);
            printf("Copied list: ");
            printList(dup);
            break;
       
        case 6:
            printList(head);
            break;
       
        case 7:
            printf("Size of link list is %d\n",Count1(head));
            break;
           
        case 8:
            printf("Enter an element to enter:");
            scanf("%d",&x);
            s=Count1(head);
            addInMid(head,x,s);
            break;

        case 9:
            exit(1);

        default:
            printf("Wrong choice is entered\n");
            break;
        }
    }
    return 0;
}

int searchNode(struct Node** head_ref, int key) {
  struct Node* current = *head_ref;

  while (current != NULL) {
  if (current->data == key) return 1;
  current = current->next;
  }
  return 0;
}
